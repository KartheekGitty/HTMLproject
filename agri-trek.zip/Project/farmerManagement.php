<?php
include "db_connect.php";

// Start the session for flash messages
session_start();

// Handle Delete Request
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];  // Get the farmer's ID from the query string

    // Prepare SQL statement to delete the farmer by ID
    $deleteQuery = "DELETE FROM farmers WHERE id = ?";
    $stmt = $conn->prepare($deleteQuery);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // Set session variable for success message
        $_SESSION['message'] = "Farmer deleted successfully!";
        // Redirect to the same page to reflect the changes
        header("Location: farmerManagement.php");
        exit();
    } else {
        $_SESSION['message'] = "Error deleting record: " . $conn->error;
    }
}

// Handle Search Request
$searchQuery = "";
if (isset($_POST['search'])) {
    $search = $_POST['search'];
    $searchQuery = "WHERE name LIKE '%$search%'";
}

// Function to Export CSV
if (isset($_POST['export_csv'])) {
    $sql = "SELECT * FROM farmers $searchQuery";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // Output headers to trigger file download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="farmers.csv"');

        $output = fopen('php://output', 'w');
        // Column headers
        fputcsv($output, ['Farmer ID', 'Name', 'Phone', 'Primary Crop', 'Land (acres)']);

        // Output data rows
        while ($row = $result->fetch_assoc()) {
            fputcsv($output, $row);
        }

        fclose($output);
        exit();
    }
}

// API endpoint to get farmer data for the chart
if (isset($_GET['data'])) {
    $sql = "SELECT primary_crop, COUNT(*) as farmer_count FROM farmers GROUP BY primary_crop";
    $result = $conn->query($sql);

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    header('Content-Type: application/json'); // Set header to JSON
    echo json_encode($data);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Farmers</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .chart-container {
            width: 80%;
            margin: auto;
        }
    </style>
    <script>
        // Check for session message and display an alert if it exists
        window.onload = function() {
            <?php if (isset($_SESSION['message'])): ?>
                alert("<?= $_SESSION['message']; ?>");
                <?php unset($_SESSION['message']); // Clear the message after showing it ?>
            <?php endif; ?>
        }

        // Function to print the page content
        function printTable() {
            var printContent = document.getElementById("farmerTable").outerHTML;
            var win = window.open('', '', 'height=800,width=1200');
            win.document.write('<html><head><title>Print Farmers</title>');
            win.document.write('</head><body>');
            win.document.write(printContent);
            win.document.write('</body></html>');
            win.document.close();
            win.print();
        }
    </script>
</head>

<body class="bg-gray-50 font-sans">
    <header class="sticky w-full top-0">
        <nav>
            <div class="grid grid-cols-2 bg-green-700 p-4">
                <div class="text-2xl text-white"><h1><span>🌿</span>Agri-Trek</h1></div>
                <div class="flex justify-end space-x-8">
                    <a href="dashboard.php" class="text-xl text-white hover:text-gray-300">Home</a>
                    <a href="schemes.php" class="text-xl text-white hover:text-gray-300">Schemes</a>
                </div>
            </div>
        </nav>
    </header>

    <div class="p-8">
    <h1 class="text-4xl font-bold mb-6 text-green-700">Farmers</h1>

<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
    <div class="flex flex-col md:flex-row gap-2">
        <form method="POST" action="farmerManagement.php" class="flex gap-2">
            <input type="text" name="search" placeholder="Search farmers..." value="<?= isset($_POST['search']) ? $_POST['search'] : ''; ?>" class="px-4 py-2 border border-gray-300 rounded-md shadow-sm w-full md:w-64">
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-md shadow">
                Search
            </button>
        </form>

    </div>
    <a href="addfarmers.php" class="self-start md:self-auto">
        <button class="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-2 rounded-md shadow">
            + Add Farmer
        </button>
    </a>
</div>

<div class="overflow-x-auto bg-white shadow-md rounded-lg">
    <table class="min-w-full divide-y divide-gray-200" id="farmerTable">
        <thead class="bg-green-700 text-white">
            <tr>
                <th class="px-6 py-3 text-left text-sm font-semibold">Farmer ID</th>
                <th class="px-6 py-3 text-left text-sm font-semibold">Name</th>
                <th class="px-6 py-3 text-left text-sm font-semibold">Phone</th>
                <th class="px-6 py-3 text-left text-sm font-semibold">Primary Crop</th>
                <th class="px-6 py-3 text-left text-sm font-semibold">Land (acres)</th>
                <th class="px-6 py-3 text-center text-sm font-semibold">Actions</th>
            </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
            <?php
            // Fetch farmers from the database with the applied search filter
            $sql = "SELECT * FROM farmers $searchQuery";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) :
                while ($row = $result->fetch_assoc()) :
            ?>
                    <tr>
                        <td class="px-6 py-4"><?= $row['id']; ?></td>
                        <td class="px-6 py-4"><?= $row['name']; ?></td>
                        <td class="px-6 py-4"><?= $row['phone']; ?></td>
                        <td class="px-6 py-4"><?= $row['primary_crop']; ?></td>
                        <td class="px-6 py-4"><?= $row['land']; ?></td>
                        <td class="px-6 py-4 text-center">
                            <div class="flex justify-center space-x-2">
                                <a href="?delete=<?= $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this farmer?');" class="bg-red-100 hover:bg-red-200 text-red-700 p-2 rounded-md">
                                    🗑️
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php
                endwhile;
            else :
                ?>
                <tr>
                    <td colspan="6" class="text-center px-6 py-4 text-gray-500">No farmers found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<p class="mt-4 text-gray-600"><?= $result->num_rows; ?> farmers found</p>

<div class="mt-6 flex space-x-4">
    <form method="POST" action="farmerManagement.php">
        <button type="submit" name="export_csv" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md shadow">Export CSV</button>
    </form>
    <button onclick="printTable()" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md shadow">Print</button>
</div>

<div class="chart-container mt-20">
    <canvas id="cropChart"></canvas>
</div>

<script>
    const ctx = document.getElementById('cropChart').getContext('2d');
    let cropChart;

    function initChart(labels = [], data = []) {
        cropChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: '# of Farmers',
                    data: data,
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Farmers'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Crop'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    function updateChart(labels, data) {
        cropChart.data.labels = labels;
        cropChart.data.datasets[0].data = data;
        cropChart.update();
    }

    function fetchData() {
        fetch('farmerManagement.php?data')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const labels = data.map(row => row.primary_crop);
                const counts = data.map(row => row.farmer_count);
                if (cropChart) {
                    updateChart(labels, counts);
                } else {
                    initChart(labels, counts);
                }
            })
            .catch(error => console.error('Error fetching data:', error));
    }

    window.addEventListener('message', function(event) {
        if (event.data === 'farmerAdded') {
            console.log('Received farmerAdded message');
            fetchData(); // Refresh the chart data
        }
    });

    // Initial chart load
    fetchData();
</script>
    </div>
</body>

</html>