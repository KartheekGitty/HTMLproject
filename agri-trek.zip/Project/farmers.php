<?php
include "db_connect.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Farmers</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 p-8 font-sans">
<header class="sticky w-full top-0">
        <nav>
            <div class="grid grid-cols-2 bg-green-700 p-4">
                <div class="text-2xl text-white"><h1><span>🌿</span>Agri-Trek</h1></div>
                <div class="flex justify-end space-x-8">
                    <a href="#home" class="text-xl text-white hover:text-gray-300">Home</a>
                    <a href="schemes.php" class="text-xl text-white hover:text-gray-300">Schemes</a>
                </div>
            </div>
        </nav>
    </header>

    <h1 class="text-4xl font-bold mb-6 text-green-700">Farmers</h1>

    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div class="flex flex-col md:flex-row gap-2">
            <input type="text" placeholder="Search farmers..." class="px-4 py-2 border border-gray-300 rounded-md shadow-sm w-full md:w-64">
            <select class="px-4 py-2 border border-gray-300 rounded-md shadow-sm w-full md:w-48">
                <option>All Crops</option>
            </select>
            <select class="px-4 py-2 border border-gray-300 rounded-md shadow-sm w-full md:w-48">
                <option>Name (A-Z)</option>
            </select>
        </div>
        <a href="add_farmer.php" class="self-start md:self-auto">
            <button class="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-2 rounded-md shadow">
                + Add Farmer
            </button>
        </a>
    </div>

    <div class="overflow-x-auto bg-white shadow-md rounded-lg">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-green-700 text-white">
                <tr>
                    <th class="px-6 py-3 text-left text-sm font-semibold">Farmer ID</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold">Name</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold">Phone</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold">Primary Crop</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold">Land (acres)</th>
                    <th class="px-6 py-3 text-center text-sm font-semibold">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php
                $sql = "SELECT * FROM farmers";
                $result = $conn->query($sql);

                if ($result->num_rows > 0):
                    while ($row = $result->fetch_assoc()):
                ?>
                <tr>
                    <td class="px-6 py-4"><?= $row['id']; ?></td>
                    <td class="px-6 py-4"><?= $row['name']; ?></td>
                    <td class="px-6 py-4"><?= $row['phone']; ?></td>
                    <td class="px-6 py-4"><?= $row['primary_crop']; ?></td>
                    <td class="px-6 py-4"><?= $row['land']; ?></td>
                    <td class="px-6 py-4 text-center">
                        <div class="flex justify-center space-x-2">
                            <button title="View" class="bg-green-100 hover:bg-green-200 text-green-700 p-2 rounded-md">
                                👁️
                            </button>
                            <button title="Edit" class="bg-yellow-100 hover:bg-yellow-200 text-yellow-700 p-2 rounded-md">
                                ✏️
                            </button>
                            <button title="Delete" class="bg-red-100 hover:bg-red-200 text-red-700 p-2 rounded-md">
                                🗑️
                            </button>
                        </div>
                    </td>
                </tr>
                <?php
                    endwhile;
                else:
                ?>
                <tr>
                    <td colspan="6" class="text-center px-6 py-4 text-gray-500">No farmers found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <p class="mt-4 text-gray-600"><?= $result->num_rows; ?> farmers found</p>

    <div class="mt-6 flex space-x-4">
        <button class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md shadow">Export CSV</button>
        <button class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md shadow">Print</button>
    </div>

</body>
</html>
