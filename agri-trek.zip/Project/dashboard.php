<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/src/output.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Agri-Trek</title>
</head>
<body>
    <header class="sticky w-full top-0">
        <nav>
            <div class="grid grid-cols-2 bg-green-700 p-4">
                <div class="text-2xl text-white"><h1><span>🌿</span>Agri-Trek</h1></div>
                <div class="flex justify-end space-x-8">
                    <a href="#home" class="text-xl text-white hover:text-gray-300">Home</a>
                    <a href="schemes.php" class="text-xl text-white hover:text-gray-300">Schemes</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section id="home">
            <div class="bg-green-600 m-10 rounded-xl text-center text-white p-5">
            <h1 class="text-3xl font-semibold">Welcome <?php echo $_SESSION['username']; ?></h1>

                <h2 class="text-2xl mt-3">"Agri-Trek: Empowering Farmers with Smart Solutions"</h2>
                <p class="mt-3 text-l">
                    Agricultural Management system for computerizing farmer details, land information, and beneficiary schemes.
                    Agri-Trek is a digital platform designed to help farmers register their land, 
                    access government schemes, and gain real-time agricultural insights. 
                    With easy-to-use tools, farmers can manage their land records, track 
                    weather patterns, and explore financial support options to enhance productivity.
                    Whether you are a small-scale farmer or managing large farmlands, Agri-Trek provides the 
                    resources and guidance needed for modern, data-driven farming.
                </p>
                
            </div>
        </section>

        <div class="grid grid-cols-3 m-10 gap-4">
            <div class="border-2 border-gray-100 rounded-md p-2 shadow-none transition-shadow duration-300 hover:shadow-lg hover:shadow-gray-400">
                <h1 class="text-2xl font-bold">Farmer Management</h1>
                <p>Register and manage farmer details including personal information, contact details, and identification documents.</p>
                <a href="farmerManagement.php" class="inline-block border-2 p-2 rounded-md mt-6 text-green-700 hover:bg-green-700 hover:text-white border-green-700">Manage Farmer</a>
            </div>

            <div class="border-2 border-gray-100 rounded-md p-2 shadow-none transition-shadow duration-300 hover:shadow-lg hover:shadow-gray-400">
                <h1 class="text-2xl font-bold">Land Information</h1>
                <p>Record and track land details including survey numbers, area, soil type, irrigation methods, and crop information.</p>
                <a href="land_registration.php" class="inline-block border-2 p-2 rounded-md mt-6 text-green-700 hover:bg-green-700 hover:text-white border-green-700">Manage Land</a>
            </div>

            <div class="border-2 border-gray-100 rounded-md p-2 shadow-none transition-shadow duration-300 hover:shadow-lg hover:shadow-gray-400">
                <h1 class="text-2xl font-bold">Beneficiary Schemes</h1>
                <p>Access various agricultural schemes and subsidies available for farmers based on eligibility criteria.</p><br>
                <a href="schemes.php" class="inline-block border-2 p-2 rounded-md mt-6 text-green-700 hover:bg-green-700 hover:text-white border-green-700">View Schemes</a>
            </div>
        </div>

        <h1 class="bg-green-600 text-center rounded-md text-2xl font-semibold ml-10 mr-10 text-white p-4">About Agri-Trek</h1>
        <div class="ml-10 mr-10 border-2 rounded-md grid grid-cols-2 gap-10 p-4 shadow-none transition-shadow duration-300 hover:shadow-lg hover:shadow-gray-400">
            <div>
                <p class="mt-3">
                    <strong>Our Mission</strong><br>
                    Agri-Trek aims to streamline agricultural management processes by providing a comprehensive digital platform for recording and managing farmer details, land information, and beneficiary schemes.
                    Our system enhances accuracy, reduces paperwork, and provides valuable insights through data-driven reports.
                </p>
            </div>

            <div>
                <h1 class="font-bold">Key Features:</h1>
                <ol class="list-disc text-l list-inside mt-2">
                    <li>Comprehensive farmer profile management</li>
                    <li>Detailed land record maintenance</li>
                    <li>Access to various agricultural schemes</li>
                    <li>Eligibility verification for benefits</li>
                    <li>Data-driven insights and reports</li>
                    <li>User-friendly interface for all stakeholders</li>
                </ol>
            </div>
        </div>
    </main>

    <footer class="bg-black text-white mt-10">
        <div class="grid grid-cols-3 p-4 gap-5">
            <div>
                <h1 class="text-xl">Agri-Trek</h1>
                <p>Agricultural Management System for computerizing farmer details, land information, and beneficiary schemes.</p>
            </div>

            <div>
                <h1>Quick Links</h1>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="farmermanagement.php">Farmers</a></li>
                    <li><a href="land_registration.php">Land details</a></li>
                    <li><a href="schemes.php">Schemes</a></li>
                </ul>
            </div>

            <div>
                <h1>Contact</h1>
                <ul>
                    <li>📍 517001,Chittoor,Andhra Pradesh</li>
                    <li>📞 +91 8309264043</li>
                    <li>📧 kampalletej@gmail.com</li>
                </ul>
            </div>
        </div>
    </footer>
</body>
</html>
