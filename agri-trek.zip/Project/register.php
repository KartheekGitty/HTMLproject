<?php
// Ensure error reporting is enabled for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate inputs properly to prevent SQL injection and other vulnerabilities
    $userName = filter_input(INPUT_POST, 'userName', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password']; // Password should be handled carefully

    // Basic validation
    if (empty($userName) || strlen($userName) < 3 || strlen($userName) > 20 || !preg_match('/^[a-zA-Z0-9_]+$/', $userName)) {
        echo "<script>alert('Invalid username. It should be 3-20 characters, using letters, numbers, and underscores only.');</script>";
    } elseif (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email address.');</script>";
    } elseif (empty($password) || strlen($password) < 8 || !preg_match('/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/', $password)) {
        echo "<script>alert('Invalid password. It should be at least 8 characters with at least one letter and one number.');</script>";
    } elseif (!isset($_POST['terms'])) {
        echo "<script>alert('Please agree to the terms and conditions.');</script>";
    } else {
        // Hash the password securely
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Database connection
        $conn = new mysqli('localhost', 'root', '', 'test');

        // Check for connection errors
        if ($conn->connect_error) {
            die('Connection Failed: ' . $conn->connect_error);
        } else {
            // Prepare and bind statement to insert user into the registration table
            // It's crucial to check if the username or email already exists to prevent duplicates
            $stmt = $conn->prepare("INSERT INTO registration (userName, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $userName, $email, $hashedPassword);

            // Execute the query and check for success
            if ($stmt->execute()) {
                echo "<script>alert('Registration successful!'); window.location.href = 'login.php';</script>";
                exit(); // Important to stop further script execution after redirection
            } else {
                // Check for duplicate entry errors (e.g., if username or email is unique in the database)
                if ($conn->errno === 1062) {
                    echo "<script>alert('Error: Username or email already exists.');</script>";
                } else {
                    echo "<script>alert('Error: Registration failed. Please try again.');</script>";
                    // Log the error for debugging purposes
                    error_log("Database Error: " . $stmt->error);
                }
            }

            // Close the prepared statement
            $stmt->close();
        }

        // Close the database connection
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="/src/output.css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Register</title>
</head>

<body style="background-image: url('register.jpeg');"
    class="bg-cover bg-center mb-10">

    <header class="sticky w-full top-0">
        <nav>
            <div class="grid grid-cols-2 p-4">
                <div class="text-4xl font-bold">
                    <h1><span>🌿</span>Agri-Trek</h1>
                </div>
                
            </div>
        </nav>
    </header>

    <h1 class="text-4xl font-bold mt-2 text-center">Register to Agri-Trek</h1>
    <form class="mt-10 flex justify-center items-center" method="POST">
        <div class="text-center border-2 border-black p-10 w-full text-white bg-black rounded-md max-w-md opacity-70">
            <div>
                <label for="userName" class="text-2xl font-bold">Username</label>
                <input type="text" name="userName" id="userName" required
                    class="border-black border-2 rounded-md p-1 text-black"
                    pattern="[a-zA-Z0-9_]{3,20}"
                    title="Username should be 3-20 characters, using letters, numbers, and underscores only." />
                <p class="mt-2 text-sm">(3–20 characters, letters, numbers, underscores only)</p>
            </div>

            <div class="mt-6">
                <label for="email" class="text-2xl font-bold">Email</label>
                <input type="email" name="email" id="email" required
                    class="border-black border-2 rounded-md p-1 text-black" />
            </div>

            <div class="mt-6">
                <label for="password" class="text-2xl font-bold">Password</label>
                <input type="password" name="password" id="password" required
                    class="border-black border-2 rounded-md p-1 text-black"
                    pattern="(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}"
                    title="Password should be at least 8 characters with at least one letter and one number." />
                <p class="mt-2 text-sm">Min. 8 characters, at least 1 letter and 1 number</p>
            </div>

            <div class="mt-6">
                <input type="checkbox" id="terms" name="terms" required />
                <label for="terms">I agree to the terms and conditions</label>
            </div>

            <div class="mt-6">
                <button type="submit" class="bg-green-700 rounded-md p-2 hover:bg-green-800">Register</button>
            </div>
        </div>
    </form>

</body>
</html>