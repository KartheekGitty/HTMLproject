<?php
session_start(); // Start the session to store user information upon successful login

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection details
    $servername = "localhost";
    $username = "root"; // Replace with your database username
    $password = "";     // Replace with your database password
    $dbname = "test";     // Replace with your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Sanitize and get user input
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = $_POST['password'];

    // Prepare the SQL query to fetch user details
    $sql = "SELECT id, userName, password FROM registration WHERE userName = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        // Verify the password against the hashed password in the database
        if (password_verify($password, $row['password'])) {
            // Password is correct, set session variables and redirect to a logged-in page
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['userName'];
            header("Location: dashboard.php"); // Replace with your dashboard page
            exit();
        } else {
            // Incorrect password
            $login_error = "Incorrect username or password.";
        }
    } else {
        // User not found
        $login_error = "Incorrect username or password.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/src/output.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Login to Agri-Trek</title>
</head>
<body class="bg-cover bg-center min-h-screen bg-no-repeat" style="background-image: url('login.jpg');">
    <header class="sticky w-full top-0">
        <nav>
            <div class="grid grid-cols-2 p-4">
                <div class="text-4xl font-bold"><h1><span>🌿</span>Agri-Trek</h1></div>
            </div>
        </nav>
    </header>

    <h1 class="text-4xl font-bold mt-2 text-center ">Login to Agri-Trek</h1>
    <form class="mt-20 flex justify-center items-center" method="POST">
        <div class="text-center border-2 border-black p-10 w-full text-white bg-black rounded-md max-w-md">
            <?php if (isset($login_error)): ?>
                <p class="text-red-500 mb-4"><?php echo $login_error; ?></p>
            <?php endif; ?>
            <div>
                <label for="username" class="text-2xl font-bold">Username</label>
                <input type="text" name="username" id="username" class="border-black border-2 rounded-md p-1 text-black" required>
            </div>

            <div class="mt-6">
                <label for="password" class="text-2xl font-bold">Password</label>
                <input type="password" name="password" id="password" class="border-black border-2 rounded-md p-1 text-black" required>
            </div>

            <div class="mt-6">
                <button type="submit" class="bg-green-700 rounded-md p-2 hover:bg-green-800">Login</button>
            </div>
            <div class="mt-4">
                <p>Don't have an account? <a href="register.php" class="text-green-500 hover:underline">Register here</a></p>
            </div>
        </div>
    </form>
</body>
</html>