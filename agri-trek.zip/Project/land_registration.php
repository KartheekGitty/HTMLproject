<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection details
$servername = "localhost";
$username = "root"; // Replace with your database username if different
$password = "";    // Replace with your database password if set
$dbname = "test"; // Ensure this matches your database name in phpMyAdmin

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and retrieve form data
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $aadhar = filter_input(INPUT_POST, 'aadhar', FILTER_SANITIZE_NUMBER_INT);
    $dob = filter_input(INPUT_POST, 'dob', FILTER_SANITIZE_STRING);
    $gender = filter_input(INPUT_POST, 'gender', FILTER_SANITIZE_STRING);
    $mobilenumber = filter_input(INPUT_POST, 'mobilenumber', FILTER_SANITIZE_NUMBER_INT);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
    $landowner = filter_input(INPUT_POST, 'landowner', FILTER_SANITIZE_STRING);
    $area = filter_input(INPUT_POST, 'area', FILTER_SANITIZE_NUMBER_FLOAT);
    $surveynumber = filter_input(INPUT_POST, 'surveynumber', FILTER_SANITIZE_STRING);

    // Handle file uploads
    $targetDir = "uploads/"; // Ensure this directory exists and is writable by the web server
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $aadhar_file_name = !empty($_FILES["aadhar-file"]["name"]) ? basename($_FILES["aadhar-file"]["name"]) : "";
    $landownershipdoc_file_name = !empty($_FILES["landownershipdoc"]["name"]) ? basename($_FILES["landownershipdoc"]["name"]) : "";
    $bankpassbook_file_name = !empty($_FILES["bankpassbook"]["name"]) ? basename($_FILES["bankpassbook"]["name"]) : "";
    $recentphoto_file_name = !empty($_FILES["recentphoto"]["name"]) ? basename($_FILES["recentphoto"]["name"]) : "";

    $aadhar_file_path = $targetDir . $aadhar_file_name;
    $landownershipdoc_file_path = $targetDir . $landownershipdoc_file_name;
    $bankpassbook_file_path = $targetDir . $bankpassbook_file_name;
    $recentphoto_file_path = $targetDir . $recentphoto_file_name;

    $uploadOk = 1;
    $error_message = "";

    // Basic file upload checks (you might want to add more robust checks)
    $allowedFileType = ['image/jpeg', 'image/png', 'application/pdf'];

    foreach ($_FILES as $key => $file) {
        if ($file["size"] > 0) {
            if (!in_array($file["type"], $allowedFileType)) {
                $error_message .= "Invalid file type for " . str_replace("-file", "", $key) . ". Only JPG, PNG, and PDF are allowed.<br>";
                $uploadOk = 0;
            }
            if ($file["size"] > 5 * 1024 * 1024) { // 5MB limit
                $error_message .= "File size too large for " . str_replace("-file", "", $key) . ". Maximum 5MB allowed.<br>";
                $uploadOk = 0;
            }
        } elseif ($file["error"] !== UPLOAD_ERR_NO_FILE && in_array($key, ['aadhar-file', 'landownershipdoc', 'bankpassbook', 'recentphoto'])) {
            $error_message .= "Error uploading " . str_replace("-file", "", $key) . ". Please try again.<br>";
            $uploadOk = 0;
        }
    }

    if ($uploadOk) {
        if (!empty($_FILES["aadhar-file"]["tmp_name"])) {
            move_uploaded_file($_FILES["aadhar-file"]["tmp_name"], $aadhar_file_path);
        }
        if (!empty($_FILES["landownershipdoc"]["tmp_name"])) {
            move_uploaded_file($_FILES["landownershipdoc"]["tmp_name"], $landownershipdoc_file_path);
        }
        if (!empty($_FILES["bankpassbook"]["tmp_name"])) {
            move_uploaded_file($_FILES["bankpassbook"]["tmp_name"], $bankpassbook_file_path);
        }
        if (!empty($_FILES["recentphoto"]["tmp_name"])) {
            move_uploaded_file($_FILES["recentphoto"]["tmp_name"], $recentphoto_file_path);
        }

        // Prepare and bind SQL statement to insert data
        $stmt = $conn->prepare("INSERT INTO land_registrationnss (name, aadhar_number, dob, gender, mobile_number, email_address, address, land_owner_name, total_area, survey_number, aadhar_card_path, land_ownership_doc_path, bank_passbook_path, recent_photo_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if ($stmt === false) {
            die('MySQL prepare error: ' . $conn->error); // If prepare fails, display the error
        }

        $stmt->bind_param("sissssssdsssss", $name, $aadhar, $dob, $gender, $mobilenumber, $email, $address, $landowner, $area, $surveynumber, $aadhar_file_path, $landownershipdoc_file_path, $bankpassbook_file_path, $recentphoto_file_path);

        if ($stmt->execute()) {
            // Show success message with JavaScript alert and redirect
            echo "<script>
                    alert('Registration Successful!');
                    window.location.href = 'dashboard.php';
                  </script>";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "<div style='color: red;'>Error uploading files:<br>" . $error_message . "</div>";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/src/output.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Land Registration</title>
</head>

<body class="min-h-screen flex items-center justify-center p-4">
    <form method="post" action="land_registration.php" enctype="multipart/form-data"
        class="bg-white text-gray-800 shadow-2xl rounded-2xl p-10 w-full max-w-2xl space-y-6 border border-gray-300">

        <h1 class="text-4xl font-extrabold text-center text-green-800">Land Registration</h1>

        <!-- Input Group -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label for="name" class="block font-semibold">Full Name:</label>
                <input type="text" id="name" name="name" required
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-500 p-2 border-2 border-black">
            </div>

            <div>
                <label for="aadhar" class="block font-semibold">Aadhaar Number:</label>
                <input type="text" id="aadhar" name="aadhar" maxlength="12" pattern="[0-9]{12}" required
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-500 p-2 border-2 border-black"
                    title="Please enter a 12-digit Aadhaar number">
            </div>

            <div>
                <label for="dob" class="block font-semibold">Date of Birth:</label>
                <input type="date" id="dob" name="dob" required
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-500 p-2 border-2 border-black">
            </div>

            <div>
                <label class="block font-semibold mb-1">Gender:</label>
                <div class="flex gap-6 mt-1">
                    <label class="flex items-center">
                        <input type="radio" name="gender" value="male" required class="mr-2"> Male
                    </label>
                    <label class="flex items-center">
                        <input type="radio" name="gender" value="female" class="mr-2"> Female
                    </label>
                </div>
            </div>

            <div>
                <label for="mobilenumber" class="block font-semibold">Mobile Number:</label>
                <input type="text" id="mobilenumber" name="mobilenumber" maxlength="10" pattern="[0-9]{10}" required
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-500 p-2 border-2 border-black"
                    title="Please enter a 10-digit mobile number">
            </div>

            <div>
                <label for="email" class="block font-semibold">Email Address:</label>
                <input type="email" id="email" name="email" required
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-500 p-2 border-2 border-black">
            </div>

            <div>
                <label for="address" class="block font-semibold">Address:</label>
                <input type="text" id="address" name="address" required
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-500 p-2 border-2 border-black">
            </div>

            <div>
                <label for="landowner" class="block font-semibold">Land Owner Name:</label>
                <input type="text" id="landowner" name="landowner" required
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-500 p-2 border-2 border-black">
            </div>

            <div>
                <label for="area" class="block font-semibold">Total Land Area:</label>
                <input type="text" id="area" name="area" required
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-500 p-2 border-2 border-black">
            </div>

            <div>
                <label for="surveynumber" class="block font-semibold">Survey Number:</label>
                <input type="text" id="surveynumber" name="surveynumber" required
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-500 p-2 border-2 border-black">
            </div>
        </div>

        <!-- File Uploads -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label for="aadhar-file" class="block font-semibold">Upload Aadhaar Card:</label>
                <input type="file" name="aadhar-file" id="aadhar-file"
                    class="mt-1 block w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:border-0 file:bg-green-600 file:text-white file:rounded-md file:cursor-pointer p-2 ">
            </div>

            <div>
                <label for="landownershipdoc" class="block font-semibold">Upload Land Ownership Document:</label>
                <input type="file" name="landownershipdoc" id="landownershipdoc"
                    class="mt-1 block w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:border-0 file:bg-green-600 file:text-white file:rounded-md file:cursor-pointer p-2">
            </div>

            <div>
                <label for="bankpassbook" class="block font-semibold">Upload Bank Passbook:</label>
                <input type="file" name="bankpassbook" id="bankpassbook"
                    class="mt-1 block w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:border-0 file:bg-green-600 file:text-white file:rounded-md file:cursor-pointer p-2">
            </div>

            <div>
                <label for="recentphoto" class="block font-semibold">Upload Recent Photo:</label>
                <input type="file" name="recentphoto" id="recentphoto"
                    class="mt-1 block w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:border-0 file:bg-green-600 file:text-white file:rounded-md file:cursor-pointer p-2">
            </div>
        </div>

        <div>
            <button type="submit"
                class="w-full py-3 bg-green-700 hover:bg-green-800 text-white text-lg font-semibold rounded-xl transition duration-300 shadow-md p-2">
                Register
            </button>
        </div>
    </form>
</body>
</html>
