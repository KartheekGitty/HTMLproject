<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upcoming Scheme Deadlines</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 ">
<header class="sticky w-full top-0">
        <nav>
            <div class="grid grid-cols-2 bg-green-700 p-4">
                <div class="text-2xl text-white"><h1><span>🌿</span>Agri-Trek</h1></div>
                <div class="flex justify-end space-x-8">
                    <a href="dashboard.php" class="text-xl text-white hover:text-gray-300">Home</a>
                </div>
            </div>
        </nav>
    </header>
    <div class="p-8">
        <div class="container mx-auto bg-white shadow-md rounded-md overflow-hidden">
            <div class="bg-green-600 text-white py-4 px-6">
                <h2 class="text-xl font-semibold">Upcoming Scheme Deadlines</h2>
            </div>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Scheme Name
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Category
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            End Date
                        </th>
                        <th scope="col" class="relative px-6 py-3">
                            <span class="sr-only">Action</span>
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            PM Kisan Samman Nidhi
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <span class="inline-flex items-center bg-green-200 text-green-800 text-xs font-medium rounded-full px-2.5 py-0.5">
                                Financial Support
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            31 Mar 2025
                        </td>

                        <td>
                            <a href="https://pmkisan.gov.in/" class="p-2 bg-green-700 text-white rounded-md">Register</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            National Food Security Mission
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <span class="inline-flex items-center bg-yellow-200 text-yellow-800 text-xs font-medium rounded-full px-2.5 py-0.5">
                                Food Security
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            31 Mar 2025
                        </td>

                        <td>
                            <a href="https://www.nfsm.gov.in/" class="p-2 bg-green-700 text-white rounded-md">Register</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            Micro Irrigation Fund
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <span class="inline-flex items-center bg-blue-200 text-blue-800 text-xs font-medium rounded-full px-2.5 py-0.5">
                                Irrigation
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            30 Apr 2025
                        </td>
                        
                        <td>
                            <a href="https://www.nabard.org/content1.aspx?id=1720&catid=8&mid=8" class="p-2 bg-green-700 text-white rounded-md">Register</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            Pradhan Mantri Fasal Bima Yojana
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <span class="inline-flex items-center bg-indigo-200 text-indigo-800 text-xs font-medium rounded-full px-2.5 py-0.5">
                                Insurance
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            31 May 2025
                        </td>

                        <td>
                            <a href="https://pmfby.gov.in/" class="p-2 bg-green-700 text-white rounded-md">Register</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            Soil Health Card Scheme
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <span class="inline-flex items-center bg-teal-200 text-teal-800 text-xs font-medium rounded-full px-2.5 py-0.5">
                                Soil Management
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            30 Jun 2025
                        </td>

                        <td>
                            <a href="https://soilhealth.dac.gov.in/home" class="p-2 bg-green-700 text-white rounded-md">Register</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </body>
  
</html>