<?php
include "db_connect.php"; // Make sure this file has the correct DB connection details
function generateFarmerID()
{
    return rand(1000, 9999); // Generate a random number between 1000 and 9999
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from the form
    $farmerID = generateFarmerID();
    $name = $_POST['fullname'];
    $phone = $_POST['mobilenumber'];
    $email = $_POST['email'];
    $aadhaar = $_POST['aadharnumber'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $primary_crop = $_POST['crop'];
    $farming_type = $_POST['farmingtype'];
    $experience = $_POST['experience'];
    $land = $_POST['land'];  // Land in acres (make sure to include this in the form)

    // Prepare the SQL query to insert the data into the farmers table
    $stmt = $conn->prepare("INSERT INTO farmers (id, name, phone, email, aadhaar, dob, gender, address, primary_crop, farming_type, experience, land)  
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssssssssi", $farmerID, $name, $phone, $email, $aadhaar, $dob, $gender, $address, $primary_crop, $farming_type, $experience, $land); // Include ID

    if ($stmt->execute()) {
        // Send a success response (important for AJAX)
        echo "Farmer added successfully!";
        exit();
    } else {
        // Send an error response
        echo "Error: " . $stmt->error;
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add New Farmer</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-50 p-10 bg-cover bg-center min-h-screen bg-no-repeat" style="background-image: url('farmerimage.jpg')">
    <h1 class="text-4xl font-bold text-green-700 mb-6">Add New Farmer</h1>
    <form id="addFarmerForm" method="POST" class="grid grid-cols-2 gap-4 bg-white p-6 rounded-lg shadow-md opacity-60">
        <div>
            <label class="font-semibold">Full Name</label>
            <input type="text" name="fullname" class="w-full border-2 border-black rounded p-2 " required>
        </div>
        <div>
            <label class="font-semibold">Mobile Number</label>
            <input type="text" name="mobilenumber" class="w-full border-2 border-black rounded p-2" required pattern="\d{10}" maxlength="10" title="Enter a valid 10-digit mobile number">
        </div>
        <div>
            <label class="font-semibold">Email</label>
            <input type="email" name="email" class="w-full border border-2 border-black  rounded p-2" required>
        </div>

        <div>
            <label class="font-semibold">Aadhaar Number</label>
            <input type="text" name="aadharnumber" class="w-full border-2 border-black border rounded p-2" required pattern="\d{12}" maxlength="12" title="Enter a valid 12-digit Aadhaar number">
        </div>

        <div>
            <label class="font-semibold">Date of Birth</label>
            <input type="date" name="dob" class="w-full border border-2 border-black rounded p-2" required>
        </div>
        <div>
            <label class="font-semibold">Gender</label>
            <select name="gender" class="w-full border border-2 border-black rounded p-2" required>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="others">Others</option>
            </select>
        </div>
        <div>
            <label class="font-semibold">Address</label>
            <textarea name="address" class="w-full border rounded border-2 border-black p-2" required></textarea>
        </div>
        <div>
            <label class="font-semibold">Primary Crop</label>
            <select name="crop" class="w-full border border-2 border-black rounded p-2" required>
                <option value="rice">Rice</option>
                <option value="wheat">Wheat</option>
                <option value="sugarcane">Sugarcane</option>
                <option value="cotton">Cotton</option>
                <option value="vegetables">Vegetables</option>
                <option value="fruits">Fruits</option>
                <option value="pulses">Pulses</option>
                <option value="others">Others</option>
            </select>
        </div>
        <div>
            <label class="font-semibold">Farming Type</label>
            <select name="farmingtype" class="w-full border-2 border-black  border rounded p-2" required>
                <option value="traditional">Traditional</option>
                <option value="organic">Organic</option>
                <option value="modern">Modern</option>
                <option value="mixed">Mixed</option>
            </select>
        </div>
        <div>
            <label class="font-semibold">Farming Experience (Years)</label>
            <input type="number" name="experience" class="w-full border-2 border-black border rounded p-2" required>
        </div>
        <div>
            <label class="font-semibold">Land (acres)</label>
            <input type="number" name="land" class="w-full border border-2 border-black rounded p-2" step="0.01" required>
        </div>
        <div class="col-span-2 text-center mt-4">
            <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700">Save Farmer</button>
        </div>
    </form>

    <script>
        document.getElementById('addFarmerForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission

            const formData = new FormData(this);

            fetch('addfarmers.php', { // Send data to the same page
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.text(); // Or response.json() if you send JSON back
                })
                .then(data => {
                    console.log(data); // Handle the response from PHP (e.g., success message)
                    alert('Farmer added successfully!');
                    // Optionally, clear the form here:
                    this.reset();

                    // Notify farmerManagement.php to update (if needed - see next steps)
                    if (window.opener && !window.opener.closed) {
                        window.opener.postMessage('farmerAdded', '*'); // Send message to opener
                        window.close(); // Close the add farmer window
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error adding farmer.');
                });
        });
    </script>
</body>

</html>